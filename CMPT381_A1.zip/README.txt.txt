CMPT 381 - Assignment 1 - Derek Steeg dms 244 - Prof Carl Gutwin

Assignment Instructions:
 - Simply click the 'run' arrow
 - The program should run fine

Thank you!